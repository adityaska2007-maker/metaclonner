import discord
from discord.ext import commands
import os
from dotenv import load_dotenv
import asyncio

load_dotenv()

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    if bot.user:
        print(f'{bot.user.name} is online!')
        print(f'Bot ID: {bot.user.id}')
    print('Ready to clone servers!')
    await bot.change_presence(activity=discord.Game(name="Server Cloning"))

@bot.command(name='clone')
async def clone_server(ctx, source_guild_id: int, destination_guild_id: int):
    """Clone a server structure from source to destination"""
    
    source_guild = bot.get_guild(source_guild_id)
    destination_guild = bot.get_guild(destination_guild_id)
    
    if not source_guild:
        await ctx.send(f"❌ Cannot find source server with ID: {source_guild_id}")
        return
    
    if not destination_guild:
        await ctx.send(f"❌ Cannot find destination server with ID: {destination_guild_id}")
        return
    
    if not source_guild.me.guild_permissions.administrator:
        await ctx.send(f"❌ Bot needs Administrator permissions in source server!")
        return
    
    if not destination_guild.me.guild_permissions.administrator:
        await ctx.send(f"❌ Bot needs Administrator permissions in destination server!")
        return
    
    await ctx.send(f"🚀 Starting server clone from **{source_guild.name}** to **{destination_guild.name}**...")
    
    try:
        role_mapping = {}
        
        await ctx.send("📋 Step 1/3: Cloning roles...")
        
        source_everyone = source_guild.default_role
        try:
            await destination_guild.default_role.edit(permissions=source_everyone.permissions)
            print(f"✅ Updated @everyone permissions")
        except Exception as e:
            print(f"⚠️ Failed to update @everyone permissions: {e}")
        
        source_roles = [role for role in source_guild.roles if role.name != "@everyone"]
        
        for role in source_roles:
            try:
                new_role = await destination_guild.create_role(
                    name=role.name,
                    permissions=role.permissions,
                    colour=role.colour,
                    hoist=role.hoist,
                    mentionable=role.mentionable
                )
                role_mapping[role.id] = new_role
                print(f"✅ Created role: {role.name}")
                await asyncio.sleep(0.5)
            except Exception as e:
                print(f"⚠️ Failed to create role {role.name}: {e}")
        
        await ctx.send("🔧 Adjusting role positions...")
        for role in source_roles:
            if role.id in role_mapping:
                try:
                    new_role = role_mapping[role.id]
                    await new_role.edit(position=role.position)
                    await asyncio.sleep(0.3)
                except Exception as e:
                    print(f"⚠️ Failed to set position for role {role.name}: {e}")
        
        await ctx.send(f"✅ Cloned {len(role_mapping)} roles!")
        
        await ctx.send("📁 Step 2/3: Cloning categories and channels...")
        category_mapping = {}
        
        for category in source_guild.categories:
            try:
                overwrites = {}
                for target, overwrite in category.overwrites.items():
                    if isinstance(target, discord.Role):
                        if target.id in role_mapping:
                            overwrites[role_mapping[target.id]] = overwrite
                        elif target.name == "@everyone":
                            overwrites[destination_guild.default_role] = overwrite
                    elif isinstance(target, discord.Member):
                        dest_member = destination_guild.get_member(target.id)
                        if dest_member:
                            overwrites[dest_member] = overwrite
                
                new_category = await destination_guild.create_category(
                    name=category.name,
                    overwrites=overwrites,
                    position=category.position
                )
                category_mapping[category.id] = new_category
                print(f"✅ Created category: {category.name}")
                await asyncio.sleep(0.5)
            except Exception as e:
                print(f"⚠️ Failed to create category {category.name}: {e}")
        
        await ctx.send("💬 Step 3/3: Cloning channels...")
        cloned_channels = 0
        
        for channel in source_guild.channels:
            if channel.category_id is None:
                category = None
            else:
                category = category_mapping.get(channel.category_id)
            
            try:
                overwrites = {}
                for target, overwrite in channel.overwrites.items():
                    if isinstance(target, discord.Role):
                        if target.id in role_mapping:
                            overwrites[role_mapping[target.id]] = overwrite
                        elif target.name == "@everyone":
                            overwrites[destination_guild.default_role] = overwrite
                    elif isinstance(target, discord.Member):
                        dest_member = destination_guild.get_member(target.id)
                        if dest_member:
                            overwrites[dest_member] = overwrite
                
                if isinstance(channel, discord.ForumChannel):
                    forum_kwargs = {
                        "name": channel.name,
                        "overwrites": overwrites,
                        "position": channel.position,
                        "topic": channel.topic or "",
                        "nsfw": channel.nsfw,
                        "category": category,
                        "slowmode_delay": channel.slowmode_delay
                    }
                    if hasattr(channel, 'default_auto_archive_duration') and channel.default_auto_archive_duration:
                        forum_kwargs["default_auto_archive_duration"] = channel.default_auto_archive_duration
                    if hasattr(channel, 'default_thread_slowmode_delay') and channel.default_thread_slowmode_delay:
                        forum_kwargs["default_thread_slowmode_delay"] = channel.default_thread_slowmode_delay
                    if hasattr(channel, 'default_sort_order') and channel.default_sort_order:
                        forum_kwargs["default_sort_order"] = channel.default_sort_order
                    if hasattr(channel, 'default_reaction_emoji') and channel.default_reaction_emoji:
                        forum_kwargs["default_reaction_emoji"] = channel.default_reaction_emoji
                    if hasattr(channel, 'available_tags') and channel.available_tags:
                        new_tags = []
                        for tag in channel.available_tags:
                            tag_data = {"name": tag.name, "moderated": tag.moderated}
                            if tag.emoji:
                                tag_data["emoji"] = tag.emoji
                            new_tags.append(tag_data)
                        forum_kwargs["available_tags"] = new_tags
                    
                    await destination_guild.create_forum(**forum_kwargs)
                    cloned_channels += 1
                    print(f"✅ Created forum channel: {channel.name}")
                
                elif isinstance(channel, discord.TextChannel):
                    is_news = channel.is_news()
                    new_text_channel = await destination_guild.create_text_channel(
                        name=channel.name,
                        overwrites=overwrites,
                        position=channel.position,
                        topic=channel.topic or "",
                        slowmode_delay=channel.slowmode_delay,
                        nsfw=channel.nsfw,
                        category=category,
                        news=is_news
                    )
                    if is_news:
                        print(f"✅ Created news/announcement channel: {channel.name}")
                    else:
                        print(f"✅ Created text channel: {channel.name}")
                    cloned_channels += 1
                
                elif isinstance(channel, discord.VoiceChannel):
                    await destination_guild.create_voice_channel(
                        name=channel.name,
                        overwrites=overwrites,
                        position=channel.position,
                        bitrate=channel.bitrate,
                        user_limit=channel.user_limit,
                        category=category
                    )
                    cloned_channels += 1
                    print(f"✅ Created voice channel: {channel.name}")
                
                elif isinstance(channel, discord.StageChannel):
                    await destination_guild.create_stage_channel(
                        name=channel.name,
                        overwrites=overwrites,
                        position=channel.position,
                        category=category
                    )
                    cloned_channels += 1
                    print(f"✅ Created stage channel: {channel.name}")
                
                await asyncio.sleep(0.5)
                
            except Exception as e:
                print(f"⚠️ Failed to create channel {channel.name}: {e}")
        
        await ctx.send(f"✅ Cloned {cloned_channels} channels!")
        await ctx.send(f"🎉 **Server cloning complete!** Successfully cloned **{source_guild.name}** structure to **{destination_guild.name}**")
        
    except Exception as e:
        await ctx.send(f"❌ An error occurred during cloning: {str(e)}")
        print(f"Error: {e}")

@bot.command(name='help_clone')
async def help_clone(ctx):
    """Show help for the clone command"""
    help_text = """
    **META CLONNER - Server Cloning Bot**
    
    **Usage:**
    `!clone <source_guild_id> <destination_guild_id>`
    
    **What gets cloned:**
    ✅ All roles with permissions, colors, and hierarchy
    ✅ All categories with permissions
    ✅ All text, voice, stage, and forum channels
    ✅ Channel permissions for both roles and members
    ✅ Channel settings (topics, slowmode, NSFW, etc)
    
    **Requirements:**
    - Bot must have Administrator permissions in both servers
    - You must have permission to use commands in the server
    - For member permissions: users must exist in both servers
    
    **Example:**
    `!clone 123456789012345678 987654321098765432`
    """
    await ctx.send(help_text)

TOKEN = os.getenv('DISCORD_BOT_TOKEN')

if not TOKEN:
    print("ERROR: DISCORD_BOT_TOKEN not found in environment variables!")
    print("Please add your Discord bot token to the Secrets.")
else:
    bot.run(TOKEN)
