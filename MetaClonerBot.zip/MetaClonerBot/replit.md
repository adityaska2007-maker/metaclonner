# Overview

This is a Discord bot application built with discord.py named "META CLONNER" that provides comprehensive server cloning functionality. The bot allows users to replicate the complete structure of one Discord server to another, including all channels, roles, categories, permissions, and settings. It uses traditional prefix commands (`!clone`) for interaction and requires administrator permissions in both source and destination servers to function properly. The bot must be a member of both servers to perform cloning operations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
- **Technology**: discord.py with commands extension
- **Rationale**: discord.py is the most mature and feature-complete Python library for Discord bot development, providing robust abstractions for Discord's API
- **Command System**: Traditional prefix-based commands (`!clone`) for simplicity and backward compatibility
- **Intent Configuration**: Enables guilds, members, and message_content intents to access server structure and user data

## Authentication & Permissions
- **Token Management**: Environment variables via python-dotenv for secure credential storage
- **Permission Model**: Requires administrator permissions on both source and destination servers
- **Rationale**: Administrator access is necessary to read all server configurations and create/modify channels, roles, and settings

## Core Features
- **Server Cloning**: Asynchronous operation that copies server structure between Discord guilds
- **Permission Validation**: Pre-flight checks ensure bot has necessary permissions before attempting clone operations
- **Status Feedback**: Real-time status updates during clone process via Discord messages

## Asynchronous Architecture
- **Design Pattern**: Event-driven architecture using asyncio
- **Rationale**: Discord API requires asynchronous operations; asyncio provides efficient handling of I/O-bound operations like API calls
- **Event Handlers**: `on_ready` event for initialization and status updates

## Data Mapping
- **Role Mapping Strategy**: Maintains a mapping dictionary to correlate source roles with newly created destination roles
- **Purpose**: Ensures channel permissions and role hierarchies are preserved during cloning

# External Dependencies

## Discord API
- **Library**: discord.py
- **Purpose**: Interface with Discord's REST and Gateway APIs
- **Key Features Used**: Guild management, role creation, channel management, permissions handling

## Environment Management
- **Library**: python-dotenv
- **Purpose**: Load Discord bot token from `.env` file
- **Security**: Prevents hardcoding sensitive credentials in source code

## Required Configuration
- **Environment Variable**: `DISCORD_TOKEN` must be set in `.env` file
- **Bot Permissions**: Administrator permission in both source and destination Discord servers
- **Bot Intents**: Guilds, Members, and Message Content intents must be enabled in Discord Developer Portal